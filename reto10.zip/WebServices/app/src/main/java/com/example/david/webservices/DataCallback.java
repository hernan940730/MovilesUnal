package com.example.david.webservices;

public interface DataCallback<T> {
    void onDataReceived(T data);
}
