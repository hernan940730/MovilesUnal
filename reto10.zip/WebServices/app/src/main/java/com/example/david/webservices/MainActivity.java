package com.example.david.webservices;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private ListView nativeHostelsListView;
    private ArrayAdapter<String> nativeHostelsArrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nativeHostelsListView = (ListView) findViewById(R.id.native_hostels_list_view);
        nativeHostelsArrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        nativeHostelsListView.setAdapter(nativeHostelsArrayAdapter);
        getNativeHostels();
    }

    private void getNativeHostels() {
        URLConnectorHelper helper = new URLConnectorHelper();
        helper.addJSONArrayHTTPGetListener(new DataCallback<JSONArray>() {
            @Override
            public void onDataReceived(JSONArray data) {
                if (data == null) {
                    return;
                }
                for (int i = 0; i < data.length(); ++i) {
                    try {
                        JSONObject hostelJSON = data.getJSONObject(i);
                        StringBuilder sb = new StringBuilder();

                        sb.append("Name: ");
                        sb.append(hostelJSON.getString("nombre_comercial"));
                        sb.append("\n");

                        sb.append("Address: ");
                        sb.append(hostelJSON.getString("direccion_comercial"));
                        sb.append("\n");

                        sb.append("Phone Number: ");
                        sb.append(hostelJSON.getString("telefono"));
                        sb.append("\n");

                        sb.append("Fax: ");
                        sb.append(hostelJSON.getString("fax"));
                        sb.append("\n");

                        sb.append("Number of Rooms: ");
                        sb.append(hostelJSON.getString("numero_habitaciones"));
                        sb.append("\n");

                        sb.append("Number of Beds: ");
                        sb.append(hostelJSON.getString("numero_de_camas"));
                        sb.append("\n");

                        sb.append("NIT: ");
                        sb.append(hostelJSON.getString("nit"));
                        sb.append("\n");

                        sb.append("National Tourism Register: ");
                        sb.append(hostelJSON.getString("registro_nacional_de_turismo"));
                        sb.append("\n");

                        nativeHostelsArrayAdapter.add(sb.toString());

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        }, getString(R.string.gov_api));
    }

}
