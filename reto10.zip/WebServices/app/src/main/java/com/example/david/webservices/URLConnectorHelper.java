package com.example.david.webservices;

import android.os.AsyncTask;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;


public class URLConnectorHelper {

    public void addJSONArrayHTTPGetListener(DataCallback<JSONArray> dataCallback, String url) {
        JSONArrayHelper helper = new JSONArrayHelper(dataCallback);
        helper.execute(url);
    }

    private class JSONArrayHelper extends AsyncTask<String, Void, JSONArray> {

        private DataCallback<JSONArray> dataCallback;

        private JSONArrayHelper(DataCallback<JSONArray> dataCallback) {
            this.dataCallback = dataCallback;
        }

        @Override
        protected JSONArray doInBackground(String... params) {
            return getJSONArray(params[0]);
        }

        @Override
        protected void onPostExecute(JSONArray jsonArray) {
            super.onPostExecute(jsonArray);
            dataCallback.onDataReceived(jsonArray);
        }

        private JSONArray getJSONArray(String urlDir) {
            JSONArray jsonArray = null;
            try {
                URL url = new URL(urlDir);
                HttpsURLConnection urlConnection = (HttpsURLConnection) url.openConnection();

                InputStream stream = new BufferedInputStream(urlConnection.getInputStream());
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(stream));
                StringBuilder builder = new StringBuilder();

                String inputString;
                while ((inputString = bufferedReader.readLine()) != null) {
                    builder.append(inputString);
                }
                jsonArray = new JSONArray(builder.toString());

                urlConnection.disconnect();
            } catch (IOException | JSONException e) {
                e.printStackTrace();
            }
            return jsonArray;
        }
    }
}
