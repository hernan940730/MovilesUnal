package com.example.david.androidtictactoe;

import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.TreeMap;
import java.util.concurrent.Semaphore;

/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 */
public class GameActivity extends AppCompatActivity {

    private Button returnButton;
    private Button restartButton;

    private TextView endGameMessage;

    private static int BOARD_SIZE = 3;
    private ArrayList<Button> cells;
    private ArrayList<Integer> cellsBorders;

    private LinearLayout boardLayout;
    private TicTacToeConsole game;
    private Semaphore lockComputer;

    private Thread gameThread;

    private TextView humanScoreView;
    private TextView androidScoreView;
    private TextView tieScoreView;

    private int win = 0;
    private int buttonDim = 200;
    private int buttonPadding = 50;

    private boolean killThread;

    public static final String DIFFICULTY_BUNDLE = "DIFFICULTY";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        lockComputer = new Semaphore(0);
        cells = new ArrayList<>();
        cellsBorders = new ArrayList<>();

        returnButton = (Button) findViewById(R.id.return_button);
        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GameActivity.this.onBackPressed();
            }
        });

        restartButton = (Button) findViewById(R.id.restart_button);
        restartButton.setOnClickListener (new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                restartGame();
            }
        });

        endGameMessage = (TextView) findViewById(R.id.end_game_message);
        boardLayout = (LinearLayout) findViewById(R.id.board_layout);

        for (int i = 0; i < BOARD_SIZE; ++i) {
            for (int j = 0; j < BOARD_SIZE; ++j) {
                int border = 0;
                if(i == 0 || i == 1) {
                    border |= FigureDrawing.BUTTOM_BORDER;
                }
                if(i == 1 || i == 2) {
                    border |= FigureDrawing.TOP_BORDER;
                }
                if(j == 0 || j == 1) {
                    border |= FigureDrawing.RIGHT_BORDER;
                }
                if(j == 1 || j == 2) {
                    border |= FigureDrawing.LEFT_BORDER;
                }
                cellsBorders.add(border);
            }
        }

        for (int i = 0; i < BOARD_SIZE; ++i) {
            LinearLayout l = new LinearLayout(this);
            l.setGravity(Gravity.CENTER);
            for (int j = 0; j < BOARD_SIZE; ++j) {
                Button b = new Button(this);
                b.setLayoutParams(new LinearLayout.LayoutParams(buttonDim, buttonDim));
                b.setOnClickListener(new CellClickListener(i, j));
                b.setBackground(new FigureDrawing(buttonDim, buttonDim, cellsBorders.get(i * BOARD_SIZE + j)));
                l.addView(b);
                cells.add(b);
            }
            boardLayout.addView(l);
        }

        humanScoreView = (TextView) findViewById(R.id.human_score);
        androidScoreView = (TextView) findViewById(R.id.android_score);
        tieScoreView = (TextView) findViewById(R.id.tie_score);

    }

    @Override
    public void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        Bundle bundle = getIntent().getExtras();

        TicTacToeConsole.DifficultyLevel diff = TicTacToeConsole.DifficultyLevel.Easy;
        if (bundle != null && bundle.containsKey(DIFFICULTY_BUNDLE)) {
            diff = (TicTacToeConsole.DifficultyLevel) bundle.getSerializable(DIFFICULTY_BUNDLE);
        }

        game = new TicTacToeConsole(diff);
        gameThread = new Thread(new GameController());
        gameThread.start();
    }

    private void killThread() {
        this.killThread = true;
        lockComputer.release();
        try {
            lockComputer.acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void clearCells () {
        int i = 0;
        for (Button b : cells) {
            b.setText("");
            b.setBackground(new FigureDrawing(b.getWidth(), b.getHeight(), cellsBorders.get(i)));
            ++i;
        }
    }

    private void restartGame () {
        killThread();
        game.restart();
        clearCells();
        endGameMessage.setText("");
        gameThread = new Thread(new GameController());
        gameThread.start();
    }

    private class CellClickListener implements View.OnClickListener {

        private int move = -1;

        private CellClickListener(int i, int j) {
            move = i * BOARD_SIZE + j + 1;
        }

        @Override
        public void onClick(View view) {
            if (win == 0 && game.getTurn() == game.HUMAN_PLAYER) {
                if (game.getUserMove(move)) {

                    Button b = cells.get(move - 1);
                    //b.setText(game.HUMAN_PLAYER + "");
                    b.setBackground (new FigureDrawing (
                            game.HUMAN_PLAYER,
                            b.getWidth(),
                            b.getHeight(),
                            buttonPadding,
                            cellsBorders.get(move - 1)));
                    lockComputer.release();
                }
            }
        }
    }

    private class GameController implements Runnable {
        @Override
        public void run() {

            killThread = false;
            win = 0;

            while (win == 0)
            {
                if (game.getTurn() == game.HUMAN_PLAYER){
                    try {
                        lockComputer.acquire();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                else if (game.getTurn() == game.COMPUTER_PLAYER)
                {
                    runOnUiThread( new Runnable() {
                        @Override
                        public void run() {
                            int move = game.getComputerMove();
                            Button b = cells.get(move);
                            b.setBackground(new FigureDrawing(
                                    game.COMPUTER_PLAYER,
                                    b.getWidth(),
                                    b.getHeight(),
                                    buttonPadding,
                                    cellsBorders.get(move)));
                            lockComputer.release();
                        }
                    });
                    try {
                        lockComputer.acquire();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                if (killThread) {
                    lockComputer.release();
                    return;
                }

                game.nextTurn();
                game.displayBoard();
                win = game.checkForWinner();
            }

            game.updateScore();

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (win == 1) {
                        endGameMessage.setText(R.string.tie);
                    }
                    else if (win == 2) {
                        endGameMessage.setText(R.string.x_player_won);
                    }
                    else if (win == 3) {
                        endGameMessage.setText(R.string.o_player_won);
                    }
                    else {
                        endGameMessage.setText(R.string.error);
                    }

                    TreeMap<String, Integer> scores = game.getScores();

                    humanScoreView.setText("Human: " + scores.get("HUMAN"));
                    androidScoreView.setText("Android: " + scores.get("ANDROID"));
                    tieScoreView.setText("Tie: " + scores.get("TIE"));
                }
            });
        }
    }
}