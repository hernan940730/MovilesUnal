package com.example.david.googlemapsapp;


import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.maps.model.LatLng;


/**
 * A simple {@link Fragment} subclass.
 */
public class SetKilometersDialogFragment extends DialogFragment {


    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        final MapsActivity activity = (MapsActivity) getActivity();

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        LayoutInflater inflater = getActivity().getLayoutInflater();

        final View view = inflater.inflate(R.layout.dialog_kilometers, null);

        builder.setView(view);

        builder.setTitle(R.string.kilometers_dialog_title)
                .setPositiveButton(R.string.accept, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        String editTextVal = String.valueOf(((EditText) view.findViewById(R.id.kilometers_edit_text))
                                .getText());

                        if (editTextVal.equals("")) {
                            Toast.makeText(activity, "No kilometers provided", Toast.LENGTH_SHORT).show();
                            activity.getSupportFragmentManager().popBackStack();
                            return;
                        }

                        final double kilometers = Double.parseDouble(editTextVal);

                        SharedPreferences sharedPref = getActivity().getPreferences(Context.MODE_PRIVATE);

                        SharedPreferences.Editor editor = sharedPref.edit();

                        editor.putFloat(getString(R.string.kilometers_preference), (float)kilometers);
                        editor.commit();
                        if (ActivityCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_FINE_LOCATION) !=
                                PackageManager.PERMISSION_GRANTED) {
                            activity.getSupportFragmentManager().popBackStack();
                            return;
                        }

                        activity.getMLocationManager().requestSingleUpdate(LocationManager.GPS_PROVIDER,
                                new LocationListener() {
                                    @Override
                                    public void onLocationChanged(Location location) {
                                        LatLng latLngLocation = new LatLng(location.getLatitude(), location.getLongitude());
                                        activity.showNearbyPlaces(latLngLocation, kilometers);
                                    }

                                    @Override
                                    public void onStatusChanged(String provider, int status, Bundle extras) {

                                    }

                                    @Override
                                    public void onProviderEnabled(String provider) {

                                    }

                                    @Override
                                    public void onProviderDisabled(String provider) {

                                    }
                                }, null);

                    }
                })
                .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        activity.getSupportFragmentManager().popBackStack();
                    }
                });

        return builder.create();
    }
}
