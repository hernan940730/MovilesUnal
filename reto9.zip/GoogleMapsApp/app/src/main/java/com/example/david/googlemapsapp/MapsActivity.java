package com.example.david.googlemapsapp;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import com.google.android.gms.location.places.AutocompletePrediction;
import com.google.android.gms.location.places.AutocompletePredictionBufferResponse;
import com.google.android.gms.location.places.GeoDataClient;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.PlaceDetectionClient;
import com.google.android.gms.location.places.PlaceLikelihood;
import com.google.android.gms.location.places.PlaceLikelihoodBufferResponse;
import com.google.android.gms.location.places.Places;
import com.google.android.gms.location.places.PlacesOptions;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PointOfInterest;
import com.google.android.gms.tasks.OnSuccessListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;


public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private SupportMapFragment mMapFragment;
    private LocationManager mLocationManager;

    private List<Marker> placesMarkers;

    public static final float DEFAULT_ZOOM = 15;

    public static final int LOCATION_REQUEST_CODE = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_maps);

        placesMarkers = new ArrayList<>();

        mLocationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

        mMapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mMapFragment.getMapAsync(this);

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(
                this, R.raw.map_style_json));

        enableMyLocation(true);
        //showNearbyPlaces();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.kilometers_menu_item:
                openSetKilometersDialog();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case LOCATION_REQUEST_CODE:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    enableMyLocation(false);
                }
                break;
        }
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(false);
    }

    private void enableMyLocation(boolean requestPermission) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) !=
                PackageManager.PERMISSION_GRANTED) {
            if (requestPermission) {
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        LOCATION_REQUEST_CODE
                );
            }
            return;
        }
        mMap.setMyLocationEnabled(true);
        mLocationManager.requestSingleUpdate(LocationManager.GPS_PROVIDER, new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                LatLng latLngLocation = new LatLng(location.getLatitude(), location.getLongitude());
                mMap.animateCamera(CameraUpdateFactory.newCameraPosition(
                        CameraPosition.fromLatLngZoom(
                                latLngLocation, DEFAULT_ZOOM
                        )
                        )
                );
                SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);
                showNearbyPlaces(latLngLocation, sharedPref.getFloat(getString(R.string.kilometers_preference), 1));
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {

            }

            @Override
            public void onProviderEnabled(String provider) {

            }

            @Override
            public void onProviderDisabled(String provider) {

            }
        }, null);
    }

    private void openSetKilometersDialog() {
        DialogFragment dialogFragment = new SetKilometersDialogFragment();
        dialogFragment.show(getSupportFragmentManager(), "set_kilometers");
    }

    protected void showNearbyPlaces(final LatLng userLatLng, final double kilometers) {

        for (Marker placeMarker : placesMarkers) {
            placeMarker.remove();
        }
        placesMarkers.clear();

        HandlerThread thread = new HandlerThread("MyHandlerThread");
        thread.start();

        Handler handler = new Handler(thread.getLooper());
        handler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    StringBuilder sb = new StringBuilder();
                    sb.append("https://maps.googleapis.com/maps/api/place/nearbysearch/json?");
                    sb.append("location=" + userLatLng.latitude + "," + userLatLng.longitude);
                    sb.append("&radius=" + kilometers * 1000);
                    sb.append("&key=" + getResources().getString(R.string.google_places_key));
                    UrlConnectionHelper urlConnectionHelper = new UrlConnectionHelper();
                    JSONObject places = urlConnectionHelper.getJsonObject(sb.toString());
                    JSONArray placesInfos = places.getJSONArray("results");
                    for (int i = 0; i < placesInfos.length(); ++i) {
                        JSONObject placeInfo = placesInfos.getJSONObject(i);
                        JSONObject location = placeInfo.getJSONObject("geometry")
                                .getJSONObject("location");

                        LatLng placeLatLng = new LatLng(location.getDouble("lat"), location.getDouble("lng"));
                        String iconUrl = placeInfo.getString("icon");
                        String name = placeInfo.getString("name");
                        String vicinity = placeInfo.getString("vicinity");

                        final MarkerOptions placeMarkerOptions = new MarkerOptions();
                        placeMarkerOptions.title(name)
                                .snippet(vicinity)
                                .position(placeLatLng)
                                .icon(BitmapDescriptorFactory.fromBitmap(urlConnectionHelper.getBitmap(iconUrl)));
                        runOnUiThread(
                                new Runnable() {
                                    @Override
                                    public void run() {
                                        placesMarkers.add(mMap.addMarker(placeMarkerOptions));
                                    }
                                }
                        );

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public LocationManager getMLocationManager() {
        return mLocationManager;
    }

}
