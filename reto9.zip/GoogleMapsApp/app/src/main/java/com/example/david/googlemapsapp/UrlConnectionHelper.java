package com.example.david.googlemapsapp;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutionException;

/**
 * Created by david on 20/11/17.
 */

public class UrlConnectionHelper {

    public JSONObject getJsonObject(String url) {
        try {
            return new AsyncTask<String, Void, JSONObject>() {
                @Override
                protected JSONObject doInBackground(String... urls) {
                    try {
                        return getResponseJSON (urls[0]);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    return null;
                }

                private JSONObject getResponseJSON(String stringUrl) throws IOException {
                    URL url = new URL (stringUrl);
                    HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();
                    return getResponseJSON (httpConn);
                }

                private JSONObject getResponseJSON(HttpURLConnection httpConn) throws IOException {
                    StringBuilder response  = new StringBuilder();

                    if (httpConn.getResponseCode() == HttpURLConnection.HTTP_OK)
                    {
                        BufferedReader input = new BufferedReader(
                                new InputStreamReader(httpConn.getInputStream()), 8192);
                        String strLine;
                        while ((strLine = input.readLine()) != null)
                        {
                            response.append(strLine);
                        }
                        input.close();
                    }
                    JSONObject json = null;

                    try {
                        json = new JSONObject(response.toString());
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    return json;
                }
            }.execute(url).get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Bitmap getBitmap(String url) {
        try {
            return new AsyncTask<String, Void, Bitmap>() {

                @Override
                protected Bitmap doInBackground(String... params) {
                    try {
                        return getResponseBitmap(params[0]);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    return null;
                }

                private Bitmap getResponseBitmap(String stringUrl) throws IOException {
                    URL url = new URL (stringUrl);
                    HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();
                    return getResponseJSON (httpConn);
                }

                private Bitmap getResponseJSON(HttpURLConnection httpConn) throws IOException {

                    Bitmap bitmap = null;

                    if (httpConn.getResponseCode() == HttpURLConnection.HTTP_OK)
                    {
                        BufferedInputStream input = new BufferedInputStream(httpConn.getInputStream());
                        bitmap = BitmapFactory.decodeStream(input);
                    }

                    return bitmap;
                }

            }.execute(url).get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
        return null;
    }

}
