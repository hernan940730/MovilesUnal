package com.example.david.androidtictactoe;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.support.annotation.IntRange;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

/**
 * Created by david on 8/17/17.
 */

public class FigureDrawing extends Drawable {

    private char figure;

    private int dimx;
    private int dimy;
    private int opacity;
    private int alpha;
    private int padding;
    private int border = 0;

    final private int STROKE_WIDTH = 8;

    final static public int LEFT_BORDER = 1;
    final static public int RIGHT_BORDER = 1 << 1;
    final static public int TOP_BORDER = 1 << 2;
    final static public int BUTTOM_BORDER = 1 << 3;

    private Paint paint;

    private ColorFilter colorFilter;


    public FigureDrawing (int dimx, int dimy, int border) {
        this.dimx = dimx;
        this.dimy = dimy;

        paint = new Paint();
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(STROKE_WIDTH);
        this.border = border;

    }

    public FigureDrawing(char figure, int dimx, int dimy, int padding, int border) {
        this.figure = figure;
        this.dimx = dimx;
        this.dimy = dimy;
        this.padding = padding;
        this.border = border;

        paint = new Paint();
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(STROKE_WIDTH);
    }

    @Override
    public void draw(@NonNull Canvas canvas) {

        int cx = dimx / 2;
        int cy = dimy / 2;
        int minDim = Math.min(cx, cy);

        paint.setColor(Color.BLACK);

        if ((border & TOP_BORDER) != 0) {
            canvas.drawLine(0, 0, dimx, 0, paint);
        }
        if ((border & BUTTOM_BORDER) != 0) {
            canvas.drawLine(0, dimy, dimx, dimy, paint);
        }
        if ((border & LEFT_BORDER) != 0) {
            canvas.drawLine(0, dimy, 0, 0, paint);
        }
        if ((border & RIGHT_BORDER) != 0) {
            canvas.drawLine(dimx, dimy, dimx, 0, paint);
        }

        if (figure == TicTacToeConsole.COMPUTER_PLAYER) {
            paint.setColor(Color.RED);

            canvas.drawArc(
                    cx - minDim + padding,
                    cy + minDim - padding,
                    cx + minDim - padding,
                    cy - minDim + padding,
                    0,
                    360,
                    true,
                    paint
            );

        }
        else if (figure == TicTacToeConsole.HUMAN_PLAYER) {
            paint.setColor(Color.BLUE);
            int fromx = cx - minDim + padding;
            int tox = cx + minDim - padding;
            int fromy = cy - minDim + padding;
            int toy = cy + minDim - padding;
            canvas.drawLine(
                    fromx,
                    fromy,
                    tox,
                    toy,
                    paint
            );

            canvas.drawLine(
                    fromx,
                    toy,
                    tox,
                    fromy,
                    paint
            );
        }
    }

    @Override
    public void setAlpha(@IntRange(from = 0, to = 255) int i) {
        alpha = i;
    }

    @Override
    public void setColorFilter(@Nullable ColorFilter colorFilter) {
        this.colorFilter = colorFilter;
    }

    @Override
    public int getOpacity() {
        return opacity;
    }
}
