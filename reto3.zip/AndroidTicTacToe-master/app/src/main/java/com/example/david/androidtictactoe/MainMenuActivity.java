package com.example.david.androidtictactoe;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 */
public class MainMenuActivity extends AppCompatActivity {

    private Button startGameButton;
    private Button aboutButton;
    private FrameLayout backgroundLayout;
    private PopupWindow popUpWindow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        popUpWindow = new PopupWindow(MainMenuActivity.this);
        TextView aboutText = new TextView(MainMenuActivity.this);
        aboutText.setText(
                "Developed by:\n\n" +
                        "\tHernán David Olarte Bolivar\n\n" +
                        "\thdolarteb@unal.edu.co\n\n" +
                        "\tUniversidad Nacional de Colombia");
        aboutText.setTextColor(Color.WHITE);
        int padding = 25;
        aboutText.setPadding(padding, padding, padding, padding);
        popUpWindow.setContentView(aboutText);
        popUpWindow.setAnimationStyle(R.style.Animation);

        backgroundLayout = (FrameLayout) findViewById(R.id.background_layout);
        startGameButton = (Button) findViewById(R.id.start_game_button);
        startGameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainMenuActivity.this, GameActivity.class);
                startActivity(intent);
            }
        });

        aboutButton = (Button) findViewById(R.id.about_button);
        aboutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popUpWindow.showAtLocation(backgroundLayout, Gravity.CENTER, 0, 0);
            }
        });

        backgroundLayout.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                popUpWindow.dismiss();
                return false;
            }
        });

    }
}
