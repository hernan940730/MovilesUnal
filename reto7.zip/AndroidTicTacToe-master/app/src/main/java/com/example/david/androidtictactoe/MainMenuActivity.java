package com.example.david.androidtictactoe;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 */
public class MainMenuActivity extends AppCompatActivity {

    private Button startGameButton;
    private Button settingsButton;
    private Button aboutButton;
    private Button quitButton;

    private AlertDialog levelAlert;
    private AlertDialog aboutAlert;
    private AlertDialog quitAlert;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main_menu);

        final AlertDialog.Builder aboutAlertBuilder = new AlertDialog.Builder(this);
        aboutAlertBuilder.setMessage(R.string.about_message)
                .setTitle(R.string.about_title);
        aboutAlertBuilder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });

        aboutAlert = aboutAlertBuilder.create();
        aboutButton = (Button) findViewById(R.id.about_button);
        aboutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                aboutAlert.show();
            }
        });

        final AlertDialog.Builder levelAlertBuilder = new AlertDialog.Builder (this);
        levelAlertBuilder.setTitle (R.string.select_difficulty)
                .setItems( R.array.difficulty_levels, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(MainMenuActivity.this, GameActivity.class);

                        switch (which) {
                            case 0:
                                intent.putExtra (GameActivity.DIFFICULTY_BUNDLE, TicTacToeConsole.DifficultyLevel.Easy);
                                startActivity(intent);
                                break;
                            case 1:
                                intent.putExtra (GameActivity.DIFFICULTY_BUNDLE, TicTacToeConsole.DifficultyLevel.Hard);
                                startActivity(intent);
                                break;
                            case 2:
                                intent.putExtra (GameActivity.DIFFICULTY_BUNDLE, TicTacToeConsole.DifficultyLevel.Expert);
                                startActivity(intent);
                                break;
                            default:
                                //TODO show error message
                                break;
                        }
                    }
                });
        levelAlert = levelAlertBuilder.create();

        startGameButton = (Button) findViewById(R.id.start_game_button);
        startGameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainMenuActivity.this, GameActivity.class);
                SharedPreferences sharedPreferences = getSharedPreferences ("com.example.david.androidtictactoe_preferences", MODE_PRIVATE);
                int levelValue = Integer.parseInt(sharedPreferences.getString("difficulty_list", "1"));
                switch (levelValue) {
                    case 0:
                        intent.putExtra (GameActivity.DIFFICULTY_BUNDLE, TicTacToeConsole.DifficultyLevel.Easy);
                        startActivity(intent);
                        break;
                    case 1:
                        intent.putExtra (GameActivity.DIFFICULTY_BUNDLE, TicTacToeConsole.DifficultyLevel.Hard);
                        startActivity(intent);
                        break;
                    case 2:
                        intent.putExtra (GameActivity.DIFFICULTY_BUNDLE, TicTacToeConsole.DifficultyLevel.Expert);
                        startActivity(intent);
                        break;
                }
            }
        });

        final AlertDialog.Builder alertBuilder = new AlertDialog.Builder(this);
        alertBuilder.setMessage(R.string.quit_message)
                .setTitle(R.string.quit_title);
        alertBuilder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
                System.exit(0);
            }
        });
        alertBuilder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        quitAlert = alertBuilder.create();

        quitButton = (Button) findViewById(R.id.quit_button);
        quitButton.setOnClickListener (new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                quitAlert.show();
            }
        });

        settingsButton = (Button) findViewById(R.id.settings_button);

        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View view) {
                Intent intent = new Intent (MainMenuActivity.this, SettingsActivity.class);
                startActivity (intent);
            }
        });

    }
}
