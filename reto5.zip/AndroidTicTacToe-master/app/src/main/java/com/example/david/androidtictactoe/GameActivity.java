package com.example.david.androidtictactoe;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.AnimationDrawable;
import android.media.MediaPlayer;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.ContentFrameLayout;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Space;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.TreeMap;
import java.util.concurrent.Semaphore;

/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 */
public class GameActivity extends AppCompatActivity {

    private Button returnButton;
    private Button restartButton;

    private TextView endGameMessage;

    private static int BOARD_SIZE = 3;
    private ArrayList<Button> cells;

    private LinearLayout boardLayout;
    private TicTacToeConsole game;
    private Semaphore lockComputer;

    private Thread gameThread;

    private TextView humanScoreView;
    private TextView androidScoreView;
    private TextView tieScoreView;

    private int win = 0;
    private int buttonDim = 200;
    private int lineDim = 10;

    private final int SLEEP_TIME = 400;

    private boolean killThread;

    private List<MediaPlayer> winingSounds;
    private List<MediaPlayer> losingSounds;
    private List<MediaPlayer> tyingSounds;

    private Random rand;

    public static final String DIFFICULTY_BUNDLE = "DIFFICULTY";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        rand = new Random();

        winingSounds = new ArrayList<>();
        losingSounds = new ArrayList<>();
        tyingSounds = new ArrayList<>();

        setSounds();

        lockComputer = new Semaphore(0);
        cells = new ArrayList<>();

        returnButton = (Button) findViewById(R.id.return_button);
        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GameActivity.this.onBackPressed();
            }
        });

        restartButton = (Button) findViewById(R.id.restart_button);
        restartButton.setOnClickListener (new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                restartGame();
            }
        });

        endGameMessage = (TextView) findViewById(R.id.end_game_message);
        boardLayout = (LinearLayout) findViewById(R.id.board_layout);

        for (int i = 0; i < BOARD_SIZE; ++i) {
            LinearLayout l = new LinearLayout(this);
            l.setGravity(Gravity.CENTER);
            for (int j = 0; j < BOARD_SIZE; ++j) {
                Button b = new Button(this);
                b.setLayoutParams(new LinearLayout.LayoutParams(buttonDim, buttonDim));
                b.setOnClickListener(new CellClickListener(i, j));
                b.setBackground (null);
                l.addView(b);
                cells.add(b);
                if (j < BOARD_SIZE - 1) {
                    View v = new View(this);
                    v.setLayoutParams (new LinearLayout.LayoutParams (lineDim, buttonDim));
                    v.setBackgroundColor (Color.BLACK);
                    l.addView(v);
                }
            }
            boardLayout.addView(l);
            if (i < BOARD_SIZE - 1) {
                View v = new View(this);
                v.setLayoutParams (new LinearLayout.LayoutParams (buttonDim * BOARD_SIZE + lineDim * 2, lineDim));
                v.setBackgroundColor (Color.BLACK);
                boardLayout.addView(v);
            }
        }

        humanScoreView = (TextView) findViewById(R.id.human_score);
        androidScoreView = (TextView) findViewById(R.id.android_score);
        tieScoreView = (TextView) findViewById(R.id.tie_score);

    }

    @Override
    public void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        Bundle bundle = getIntent().getExtras();

        TicTacToeConsole.DifficultyLevel diff = TicTacToeConsole.DifficultyLevel.Easy;
        if (bundle != null && bundle.containsKey(DIFFICULTY_BUNDLE)) {
            diff = (TicTacToeConsole.DifficultyLevel) bundle.getSerializable(DIFFICULTY_BUNDLE);
        }

        game = new TicTacToeConsole(diff);
        gameThread = new Thread(new GameController());
        gameThread.start();
    }

    private void killThread() {
        this.killThread = true;
        lockComputer.release();
        try {
            lockComputer.acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void clearCells () {
        for (Button b : cells) {
            b.setText("");
            b.setBackground(null);
        }
    }

    private void restartGame () {
        killThread();
        game.restart();
        clearCells();
        endGameMessage.setText("");
        gameThread = new Thread(new GameController());
        gameThread.start();
    }

    private class CellClickListener implements View.OnClickListener {

        private int move = -1;

        private CellClickListener(int i, int j) {
            move = i * BOARD_SIZE + j + 1;
        }

        @Override
        public void onClick(View view) {
            if (win == 0 && game.getTurn() == TicTacToeConsole.HUMAN_PLAYER) {
                if (game.getUserMove(move)) {

                    Button b = cells.get(move - 1);
                    b.setBackgroundResource(R.drawable.cross_anim);
                    ((AnimationDrawable) b.getBackground()).start();
                    lockComputer.release();
                }
            }
        }
    }

    private class GameController implements Runnable {
        @Override
        public void run() {

            killThread = false;
            win = 0;

            while (win == 0)
            {
                if (game.getTurn() == TicTacToeConsole.HUMAN_PLAYER){
                    try {
                        lockComputer.acquire();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                else if (game.getTurn() == TicTacToeConsole.COMPUTER_PLAYER)
                {
                    try {
                        Thread.sleep (SLEEP_TIME);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    runOnUiThread( new Runnable() {
                        @Override
                        public void run() {
                            int move = game.getComputerMove();
                            Button b = cells.get(move);
                            b.setBackgroundResource(R.drawable.circle_anim);
                            ((AnimationDrawable) b.getBackground()).start();
                            lockComputer.release();
                        }
                    });
                    try {
                        lockComputer.acquire();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                if (killThread) {
                    lockComputer.release();
                    return;
                }

                game.nextTurn();
                game.displayBoard();
                win = game.checkForWinner();
            }

            game.updateScore();

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (win == 1) {
                        endGameMessage.setText(R.string.tie);
                        tyingSounds.get (rand.nextInt (tyingSounds.size())).start();
                    }
                    else if (win == 2) {
                        endGameMessage.setText(R.string.x_player_won);
                        winingSounds.get (rand.nextInt (winingSounds.size())).start();

                    }
                    else if (win == 3) {
                        endGameMessage.setText(R.string.o_player_won);
                        losingSounds.get (rand.nextInt (losingSounds.size())).start();
                    }
                    else {
                        endGameMessage.setText(R.string.error);
                    }

                    TreeMap<String, Integer> scores = game.getScores();

                    humanScoreView.setText("Human: " + scores.get("HUMAN"));
                    androidScoreView.setText("Android: " + scores.get("ANDROID"));
                    tieScoreView.setText("Tie: " + scores.get("TIE"));
                }
            });
        }
    }

    private void setSounds () {
        winingSounds.add (MediaPlayer.create (this, R.raw.win1));
        losingSounds.add (MediaPlayer.create (this, R.raw.lose1));
        tyingSounds.add (MediaPlayer.create (this, R.raw.tie1));
    }

    @Override
    protected void onResume() {
        super.onResume();
        setSounds();
    }

    @Override
    protected void onPause() {
        super.onPause();

        for (MediaPlayer player : winingSounds) {
            player.release();
        }
        for (MediaPlayer player : losingSounds) {
            player.release();
        }
        for (MediaPlayer player : tyingSounds) {
            player.release();
        }

        winingSounds.clear();
        losingSounds.clear();
        tyingSounds.clear();

    }
}