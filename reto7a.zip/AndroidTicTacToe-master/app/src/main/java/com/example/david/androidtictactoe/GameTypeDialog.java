package com.example.david.androidtictactoe;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.View;
import android.view.Window;
import android.widget.Button;

/**
 * Created by david on 26/10/17.
 */

public class GameTypeDialog extends Dialog {

    private Activity activity;

    public GameTypeDialog(@NonNull Activity activity) {
        super(activity, android.R.style.Theme_Holo_Light_Dialog);
        this.activity = activity;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setTitle("Select game type");

        setContentView(R.layout.dialog_game_types);

        Button singlePlayerButton = findViewById(R.id.single_player_button);

        singlePlayerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity, GameActivity.class);
                SharedPreferences sharedPreferences = activity.getSharedPreferences (
                        "com.example.david.androidtictactoe_preferences",
                        Context.MODE_PRIVATE
                );
                int levelValue = Integer.parseInt(sharedPreferences.getString("difficulty_list", "1"));
                switch (levelValue) {
                    case 0:
                        intent.putExtra (GameActivity.DIFFICULTY_BUNDLE, TicTacToeConsole.DifficultyLevel.Easy);
                        activity.startActivity(intent);
                        break;
                    case 1:
                        intent.putExtra (GameActivity.DIFFICULTY_BUNDLE, TicTacToeConsole.DifficultyLevel.Hard);
                        activity.startActivity(intent);
                        break;
                    case 2:
                        intent.putExtra (GameActivity.DIFFICULTY_BUNDLE, TicTacToeConsole.DifficultyLevel.Expert);
                        activity.startActivity(intent);
                        break;
                }
                dismiss();
            }
        });

        Button onlineButton = findViewById(R.id.multiplayer_button);
        onlineButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new MatchShowerDialog(activity).show();
                dismiss();
            }
        });
    }
}
