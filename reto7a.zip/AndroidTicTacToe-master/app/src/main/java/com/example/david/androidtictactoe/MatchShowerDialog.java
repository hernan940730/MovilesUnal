package com.example.david.androidtictactoe;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by david on 26/10/17.
 */

public class MatchShowerDialog extends Dialog {

    private Activity activity;
    private ChildEventListener listener;
    private StableArrayAdapter cursorAdapter;
    private ListView matchesListView;

    public MatchShowerDialog(@NonNull Activity activity) {
        super(activity, android.R.style.Theme_Holo_Light_Dialog);
        this.activity = activity;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        listener = new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                cursorAdapter.add(dataSnapshot.child("name").getValue(String.class), dataSnapshot.getKey());
                findViewById(R.id.matches_title).setVisibility(View.VISIBLE);
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        };

        FirebaseDatabase.getInstance().getReference().child("open_matches").addChildEventListener(listener);

        setTitle("Select or create game");

        setContentView(R.layout.dialog_matches_shower);

        matchesListView = findViewById(R.id.server_matches_list);

        cursorAdapter = new StableArrayAdapter(activity, R.layout.match_item);
        matchesListView.setAdapter(cursorAdapter);
        matchesListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String serverId = cursorAdapter.getServerId(id);

                FirebaseDatabase.getInstance().getReference().child("open_matches").child(serverId).removeValue();
                FirebaseDatabase.getInstance().getReference().child("active_matches")
                        .child(serverId)
                        .child("O_state").setValue("active");

                Intent intent = new Intent(activity, OnlineGameActivity.class);
                intent.putExtra(OnlineGameActivity.SERVER_ID_BUNDLE, serverId);
                intent.putExtra(OnlineGameActivity.PLAYER_BUNDLE, TicTacToeConsole.O_PLAYER);
                activity.startActivity(intent);
                dismiss();
            }
        });

        Button createMatchButton = findViewById(R.id.create_math_button);
        createMatchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference reference = FirebaseDatabase
                        .getInstance()
                        .getReference()
                        .child("open_matches")
                        .push();
                DatabaseReference reference2 = FirebaseDatabase
                        .getInstance()
                        .getReference()
                        .child("active_matches")
                        .child(reference.getKey());
                EditText matchEditText = findViewById(R.id.match_name);
                String matchName = matchEditText.getText().toString();
                reference.child("name").setValue(matchName);

                reference2.child("X_state").setValue("active");
                reference2.child("O_state").setValue("no_active");
                reference2.child("X_move").setValue(-1);
                reference2.child("O_move").setValue(-1);

                Intent intent = new Intent(activity, OnlineGameActivity.class);
                intent.putExtra(OnlineGameActivity.SERVER_ID_BUNDLE, reference.getKey());
                intent.putExtra(OnlineGameActivity.PLAYER_BUNDLE, TicTacToeConsole.X_PLAYER);
                activity.startActivity(intent);
                dismiss();
            }
        });
    }
    private class StableArrayAdapter extends ArrayAdapter<String> {

        private Map<String, Long> mIdMap;
        private Map<Long, String> mServerIdMap;

        public StableArrayAdapter(Context context, int textViewResourceId) {
            super(context, textViewResourceId);
            mIdMap = new HashMap<>();
            mServerIdMap = new HashMap<>();
        }

        public void add(String object, String serverId) {
            super.add(object);
            long id = mIdMap.size();
            mIdMap.put(object, id);
            mServerIdMap.put(id, serverId);
        }

        @Override
        public long getItemId(int position) {
            String item = getItem(position);
            return mIdMap.get(item);
        }

        @Override
        public boolean hasStableIds() {
            return true;
        }

        public String getServerId(long id) {
            return mServerIdMap.get(id);
        }

    }

    @Override
    protected void onStop() {
        super.onStop();
        FirebaseDatabase.getInstance().getReference().child("open_matches").removeEventListener(listener);
    }
}


