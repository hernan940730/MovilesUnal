package com.example.david.crud.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.david.crud.R;

public class UpdateActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
    }
}
