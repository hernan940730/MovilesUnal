package com.example.david.helloworld;

import android.support.v4.widget.TextViewCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

public class HelloWorldActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hello_world);
        final TextView dev_name = (TextView) findViewById(R.id.developer_name);
        final TextView hello_world = (TextView) findViewById(R.id.hello_world);
        dev_name.startAnimation(AnimationUtils.loadAnimation(this, android.R.anim.slide_in_left));
        hello_world.startAnimation(AnimationUtils.loadAnimation(this, android.R.anim.slide_in_left));
    }
}
